import {Component, OnInit} from '@angular/core';
import {Product} from "../../data/model/Product";
import * as exampleData from '../../../assets/item.json';


@Component({
  selector: 'app-list',
  templateUrl: './list.page.html',
  styleUrls: ['./list.page.scss'],
})

export class ListPage implements OnInit {
  items: Product[] = [];
  promoCode: string = "qwerty"
  enteredPromo: string = ""

  constructor() {
    for (let i = 0; i < 5; i++) {
      const data = new Product("Sandwich Bread",
        20000,
        0,
        0,
        "lorem ipsum dolor si amit",);
      this.items.push(data);
    }
  }

  submitCode(code: string) {
    if (code == this.promoCode) {
      this.changeDataSet(35)
    } else {
      this.changeDataSet(0)
    }
  }

  changeDataSet(promo: number) {
    this.items = []
    for (let i = 0; i < 5; i++) {
      const data = new Product("Sandwich Bread",
        20000,
        20000 - (20000 * (promo / 100)),
        promo,
        "lorem ipsum dolor si amit");
      this.items.push(data);
    }
  }

  // private parseJsonData(){
  //   const  data = <object[]> JSON.parse(JSON.stringify(exampleData))
  //   for (const dataKey in data) {
  //     this.items.push(
  //       new Product(
  //         dataKey['title'],dataKey['pric']
  //       )
  //     )
  //   }
  // }

  ngOnInit() {
  }

}
